#!/bin/bash

if ! command -v python3 &>/dev/null; then
    echo "Python3 is not installed. Please install Python3."
    exit 1
fi

if ! command -v pip3 &>/dev/null; then
    echo "pip3 is not installed. Installing pip3..."
    curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
    python3 get-pip.py
    rm get-pip.py
fi

echo "Installing required Python packages..."
pip3 install requests beautifulsoup4 scapy

if [ $? -eq 0 ]; then
    echo "All required packages have been successfully installed."
else
    echo "There was an error installing the required packages."
    exit 1
fi

